const chalk = require("chalk")
const fs = require("fs")

global.hituet = 0
global.gopayno = "-"
global.danano = "6281938681806"
global.shopeepayno = "-"
global.creator = "6283137750223@s.whatsapp.net"
global.thumb = fs.readFileSync(`./image/thumb.png`)
global.qrisdonate = fs.readFileSync(`./image/qris.jpg`)
global.fake = `© Ikhsan-BOT`
global.packname = `©`
global.author = `Ikhsan-STORE`
global.antilink = false
global.antiwame = false
global.autodltt = false
global.autosticker = false

//Global WHM

global.hostwhm = 'client-ferhostlivee.ferhosting.my.id' //Host server whm contoh : login.ditzzsenpai.wtf
global.usrwhm = 'rooot' //username whm
global.passwhm = '@@server55@@' //Password whm
global.tokenwhm = 'RR0SCJEG04ZM8IGX6HOKKVR1NYP1EUBZ' // caranya => https://www.eukhost.com/kb/how-to-generate-an-api-token-using-whm/
global.ipsrv = '128.199.202.236' //ip server whm
global.email = 'ikhsanainul5@gmail.com'


global.merchant = 'M221101PAZJ5903YO' 
global.secret = 'fcc9c3922337cd1443c071dbd3d356daebe4f908632e293241c31e8ac014c46f'
global.signature = 'ad488c46183fa32611f547ffbc5e4e10'

global.ownerNomor = '6283137750223'
global.ownerName = 'Ikhsan-Store'
global.ownerNumber = ["6283137750223@s.whatsapp.net"]
global.cek1 = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
global.mess = {
    wait: 'Tunggu Ngab',
    succes: 'Sukses',
    admin: 'Fitur Khusus Admin Bang :V',
    botAdmin: 'Saya Bukan Admin 🗿',
    owner: 'Ente Kadang-kadang Ente, Nih Khusus Owner Nih!!!',
    group: 'Hanya Bisa Digunakan Di Group',
    private: 'Hanya Bisa Digunakan Di Private Chat',
    bot: 'Bot Number User Special Features!!!',
    error: 'Error Bang Entah Kenapa :V',
    premium: 'Maaf Sebelumya Kamu Belum Premium, Silahkan Pencet Di Bawah Untuk Beli Premium',
    ikhsan: 'Fitur Ini Khusus IkhsanHost',
    buyer: 'Fitur Ini Khusus Buyer Ikhsan-Host',
}

global.bapak = [
'Wah Mantap Lu Masih Punya Bapack\nPasti Bapack Nya Kuli :v\nAwowkwokwwok\n#CandabOs',
'Aowkwwo Disini Ada Yteam :v\nLu Yteam Bro? Awowkwowk\nSabar Bro Ga Punya Bapack\n#Camda',
'Bjir Bapack Mu Ternyata Sudah Cemrai\nSedih Bro Gua Liatnya\nTapi Nih Tapi :v\nTetep Ae Lu Yteam Aowkwowkw Ngakak :v',
'Jangan #cekbapak Mulu Broo :v\nKasian Yang Yteam\nNtar Tersinggung Kan\nYahahaha Hayyuk By : Ramlan ID',
]

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
